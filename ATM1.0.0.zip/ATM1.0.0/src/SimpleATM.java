import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * 银行账户类。
 * 提供存款、取款和自动利息计算功能。
 */
class BankAccount {
    private double balance;
    private final double interestRate;

    /**
     * 构造一个带初始余额与利率的账户对象。
     * @param initialBalance 初始余额
     * @param interestRate   年利率
     */
    public BankAccount(double initialBalance, double interestRate) {
        this.balance = initialBalance;
        this.interestRate = interestRate;
    }

    /** 向账户中存入指定金额。 */
    public synchronized void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(" 存款成功！");
        } else {
            System.out.println("️ 存款金额必须大于 0！");
        }
    }

    /** 如果余额充足，从账户中取出指定金额。 */
    public synchronized void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println(" 取款成功！");
        } else if (amount > balance) {
            System.out.println(" 余额不足！");
        } else {
            System.out.println("️ 取款金额必须大于 0！");
        }
    }

    /** 获取当前余额。 */
    public synchronized double getBalance() {
        return balance;
    }

    /** 计算复利并更新余额。 */
    public synchronized void addInterest() {
        balance += balance * interestRate;
    }
}

/**
 * ATM系统服务类。
 * 包含菜单、输入验证和余额实时显示逻辑。
 */
class ATMService {
    private static final double DEFAULT_INTEREST_RATE = 0.02;
    private static final int YEAR_DURATION_MS = 5000;

    private final Scanner scanner = new Scanner(System.in);
    private final BankAccount account = new BankAccount(1000.0, DEFAULT_INTEREST_RATE);

    /** 启动ATM系统。 */
    public void start() {
        startInterestThread();
        runMainLoop();
    }

    /** 启动后台利息线程，只更新余额显示，不干扰输入。 */
    private void startInterestThread() {
        Thread interestThread = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(YEAR_DURATION_MS);
                    account.addInterest();
                    updateBalanceDisplay();
                } catch (InterruptedException e) {
                    return;
                }
            }
        });
        interestThread.setDaemon(true);
        interestThread.start();
    }

    /** 实时覆盖显示余额。 */
    private void updateBalanceDisplay() {
        System.out.print("\r 当前余额: $" + String.format("%.2f", account.getBalance()) + "     ");
        System.out.flush();
    }

    /** 主循环：显示菜单和处理用户输入。 */
    private void runMainLoop() {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n===== 简易ATM系统 =====");
            System.out.println("1. 存款  2. 取款  3. 查询余额  0. 退出");
            updateBalanceDisplay();
            System.out.println(); // 留出输入行

            int choice = getValidInt("请选择操作 (0-3): ");
            switch (choice) {
                case 1 -> {
                    double amount = getValidDouble("请输入存款金额: ");
                    account.deposit(amount);
                    updateBalanceDisplay();
                }
                case 2 -> {
                    double amount = getValidDouble("请输入取款金额: ");
                    account.withdraw(amount);
                    updateBalanceDisplay();
                }
                case 3 -> {
                    System.out.println(" 当前余额: $" + String.format("%.2f", account.getBalance()));
                }
                case 0 -> {
                    System.out.println(" 感谢使用ATM，再见！");
                    exit = true;
                }
                default -> System.out.println("️ 无效选项，请输入 0～3。");
            }
            System.out.println();
        }
    }

    /** 获取合法整数输入。 */
    private int getValidInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("️ 输入无效！请输入整数。");
                scanner.next();
            }
        }
    }

    /** 获取合法金额输入。 */
    private double getValidDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double value = scanner.nextDouble();
                if (value >= 0) return value;
                System.out.println("️ 金额不能为负数！");
            } catch (InputMismatchException e) {
                System.out.println("️ 输入无效！请输入数字。");
                scanner.next();
            }
        }
    }
}

/**
 * 主类：程序入口。
 */
public class SimpleATM {
    public static void main(String[] args) {
        new ATMService().start();
    }
}
